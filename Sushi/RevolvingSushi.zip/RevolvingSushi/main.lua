display.setStatusBar( display.HiddenStatusBar )

local storyboard = require("storyboard")
local appData = require("appData")

storyboard.gotoScene("splash")